// JavaScript Document

 var Date1 = new Date("31/03/2012");

 var Date2 = new Date("1/04/2012");



 if (Date2 > Date1)

 {

     alert('found');

 }