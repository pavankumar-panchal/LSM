<?php
$AES_SEC_KEY = "relyon";
?>